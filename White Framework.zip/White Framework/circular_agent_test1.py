from White.core.agent import Agent
from White.Teams.circular_agent import CircularAgent
from White.providers.google_gla import GoogleGLAProvider
from White.models.gemini import GeminiModel
from httpx import AsyncClient
import asyncio


custom_http_client = AsyncClient(timeout=30)
model = GeminiModel(
    'gemini-1.5-flash',
    provider=GoogleGLAProvider(api_key='', http_client=custom_http_client),
)


# Visualize = Agent(model, system_prompt="Describe in detail how the car looks, from the outside, Make sure to mention every small detail", output_type=str)
# Complete_dr= Agent(model, system_prompt="Using the above description of the car Implement the car visual using the css code", output_type=str)

# seq_agent = SequentialAgent([Visualize, Complete_dr])



Description_gen = Agent(
    model,
    system_prompt="Describe the given car, Print it",
    output_type=str
)

Details_ext = Agent(
    model,
    system_prompt="Print numbers from 1 to 10",
    output_type=str
)

List_dsc = Agent(
    model,
    system_prompt="Specify the price range it is avaiable in, Print it",
    output_type=str
)

RefAg = Agent(
    model,
    system_prompt="Mention which country it is popular in, Print it",
    output_type=str
)

criticAg= Agent(
    model, 
    system_prompt= "From the above descrption , decide if it is correct, if not tell the agent t reitterate, else stop"
)



cir_agent = CircularAgent([Description_gen, Details_ext, List_dsc, RefAg])


import asyncio

async def main():
    text = "BMW M2 competition"
    result = await cir_agent.run(input=text, max_rounds= 2, continue_decider= criticAg, use_decider_this_run= True)
    print("Final output:", result)


# async def main():
#     text = "BMW M2 competetion"
#     result = await seq_agent.run(text)
#     print("Final output (French summary):", result)

if __name__ == "__main__":
    asyncio.run(main())

