"""This means `python -m White` should run the CLI."""

from ._cli import cli_exit

if __name__ == '__main__':
    cli_exit()
