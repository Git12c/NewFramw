from __future__ import annotations as _annotations

from dataclasses import dataclass
from typing import Any, Generic, Sequence, TypeVar, Optional # Added Optional

from White.White_graph import BaseNode, End, Graph, GraphRunContext
from White.core import Agent 

InputT = TypeVar('InputT')
OutputT = TypeVar('OutputT')

class AgentRegistryEntry:
    def __init__(self, agent, input_value, output_value):
        self.agent = agent
        self.input = input_value
        self.output = output_value

    def __repr__(self):
        return f"agent={getattr(self.agent, '__class__', type(self.agent)).__name__}, input={repr(self.input)}, output={repr(self.output)}"

class AgentRegistry:
    def __init__(self):
        self.entries = []
    def add(self, agent, input_value, output_value):
        self.entries.append(AgentRegistryEntry(agent, input_value, output_value))
    def __iter__(self):
        return iter(self.entries)
    def __len__(self):
        return len(self.entries)
    def __getitem__(self, idx):
        return self.entries[idx]

    def __repr__(self):
        return f"AgentRegistry(entries={self.entries})"

@dataclass
class CircularAgentState(Generic[InputT, OutputT]):
    input: InputT                          
    output: OutputT | None = None          
    step: int = 0                          
    round: int = 0                         
    max_rounds: int = 3                    
    continue_decider: Agent | None = None  
    registry: AgentRegistry = None         

    def __repr__(self):
        return (
            f"input={repr(self.input)}, output={repr(self.output)}, step={self.step}, "
            f"round={self.round}, max_rounds={self.max_rounds}, registry_len={len(self.registry) if self.registry else 0}"
        )

@dataclass
class CircularAgentNode(BaseNode[CircularAgentState, None, Any]):

    agents: Sequence[Agent] 

    async def run(self, ctx: GraphRunContext[CircularAgentState]) -> CircularAgentNode | End[Any]:
        state = ctx.state 
        if state.registry is None:
            state.registry = AgentRegistry()

        if state.round >= state.max_rounds:
            return End(state.output)

        agent_index = state.step % len(self.agents)
        agent = self.agents[agent_index]

        result = await agent.run(state.input)

        state.registry.add(agent, state.input, getattr(result, 'output', None))

        state.output = result.output 
        print(f"step->{state.step},input=->{state.input}, output->{state.output}")
        state.input = state.output    
        state.step += 1              

        if state.step % len(self.agents) == 0:
            state.round += 1 

            if state.continue_decider:
                decision_prompt = f"Current round {state.round-1} (next is {state.round}) completed. Max rounds: {state.max_rounds}. Last output: {state.output}. Continue to the next round?"
                decision_result = await state.continue_decider.run(decision_prompt)

                if hasattr(decision_result, 'output') and not bool(decision_result.output):
                    return End(state.output) 

        return self

class CircularAgent(Graph[CircularAgentState, None, Any]):

    def __init__(self,
                 agents: Sequence[Agent],
                 default_max_rounds: int = 3,
                 default_continue_decider: Optional[Agent] = None): 

        if not agents:
            raise ValueError("The 'agents' sequence cannot be empty.")

        self.node = CircularAgentNode(agents=agents)
        super().__init__(nodes=[CircularAgentNode], name="CircularAgent") 

        self.default_max_rounds = default_max_rounds
        self.default_continue_decider = default_continue_decider

    async def run(self,
                  input: Any,
                  max_rounds: Optional[int] = None,
                  continue_decider: Optional[Agent] = None, 
                  use_decider_this_run: Optional[bool] = None
                 ) -> Any:

        effective_max_rounds = max_rounds if max_rounds is not None else self.default_max_rounds

        effective_continue_decider: Optional[Agent] = None
        if use_decider_this_run is True:
            effective_continue_decider = continue_decider if continue_decider is not None else self.default_continue_decider
        elif use_decider_this_run is False:
            effective_continue_decider = None 
        else:
            effective_continue_decider = continue_decider 

        initial_state = CircularAgentState(
            input=input,
            max_rounds=effective_max_rounds,
            continue_decider=effective_continue_decider,
            registry=AgentRegistry()
        )

        result_graph_run = await super().run(self.node, state=initial_state)

        # if hasattr(result_graph_run, 'registry'):
        #     result_graph_run.registry = initial_state.registry
        # return result_graph_run

        # if isinstance(result_graph_run, End):
        #      return result_graph_run.data
        # elif hasattr(result_graph_run, 'output'):
        #      return result_graph_run.output

        return result_graph_run