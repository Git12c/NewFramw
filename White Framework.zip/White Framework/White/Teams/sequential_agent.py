from __future__ import annotations as _annotations

from dataclasses import dataclass
from typing import Any, Generic, Sequence, TypeVar
import tempfile
import webbrowser

from White.White_state import BaseNode, End, Graph, GraphRunContext, mermaid
from White.core import Agent

InputT = TypeVar('InputT')
OutputT = TypeVar('OutputT')

class AgentRegistryEntry:
    def __init__(self, agent, input_value, output_value):
        self.agent = agent
        self.input = input_value
        self.output = output_value
        # the path, from which agent, and to what agent?

class AgentRegistry:
    def __init__(self):
        self.entries = []
    def add(self, agent, input_value, output_value):
        self.entries.append(AgentRegistryEntry(agent, input_value, output_value))
    def __iter__(self):
        return iter(self.entries)
    def __len__(self):
        return len(self.entries)
    def __getitem__(self, idx):
        return self.entries[idx]

@dataclass
class SequentialAgentState(Generic[InputT, OutputT]):
    input: InputT
    output: OutputT | None = None
    step: int = 0
    registry: AgentRegistry = None  

@dataclass
class SequentialAgentNode(BaseNode[SequentialAgentState, None, Any]):
    agents: Sequence[Agent]

    async def run(self, ctx: GraphRunContext[SequentialAgentState]) -> SequentialAgentNode | End[Any]:
        state = ctx.state
        if state.registry is None:
            state.registry = AgentRegistry()
        if state.step >= len(self.agents):
            return End(state.output)
        agent = self.agents[state.step]
        result = await agent.run(state.input)

        state.registry.add(agent, state.input, getattr(result, 'output', None))
        state.output = result.output
        state.input = state.output  
        state.step += 1
        return self  

class SequentialAgent(Graph[SequentialAgentState, None, Any]):
    def __init__(self, agents: Sequence[Agent]):
        self.node = SequentialAgentNode(agents=agents)
        super().__init__(nodes=[SequentialAgentNode], name="SequentialAgent")

    async def run(self, input: Any) -> Any:
        state = SequentialAgentState(input=input, registry=AgentRegistry())
        result = await super().run(self.node, state=state)
        if hasattr(result, 'registry'):
            result.registry = state.registry
        return result

    def show_mermaid_diagram(self):
        mermaid_code = self.mermaid_code(start_node=self.start_node)
        html = f"""
        <html>
        <head>
            <script type='module'>
                import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs';
                mermaid.initialize({{ startOnLoad: true }});
            </script>
        </head>
        <body>
            <div class='mermaid'>
            {mermaid_code}
            </div>
        </body>
        </html>
        """
        with tempfile.NamedTemporaryFile('w', delete=False, suffix='.html') as f:
            f.write(html)
            temp_path = f.name
        webbrowser.open(f'file://{temp_path}')
