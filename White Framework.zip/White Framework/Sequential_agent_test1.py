from White.core.agent.agent import Agent
# from WhiteAgent.sequential_agent.sequential_agent import SequentialAgent
from White.Teams.sequential_agent import SequentialAgent
from White.providers.google_gla import GoogleGLAProvider
from White.models.gemini import GeminiModel
from httpx import AsyncClient
import asyncio

# GoogleGLAProvider(api_key="AIzaSyBvNs3gu-97GrpcFIGyED4QbJZIJrriZn8")

custom_http_client = AsyncClient(timeout=30)
model = GeminiModel(
    'gemini-2.0-flash',
    provider=GoogleGLAProvider(api_key='', http_client=custom_http_client),
)


# Visualize = Agent(model, system_prompt="Describe in detail how the car looks, from the outside, Make sure to mention every small detail", output_type=str)
# Complete_dr= Agent(model, system_prompt="Using the above description of the car Implement the car visual using the css code", output_type=str)

# seq_agent = SequentialAgent([Visualize, Complete_dr])



Visualize = Agent(
    model,
    system_prompt="Describe about a given topic with detailed description",
    output_type=str
)

RefineDescription = Agent(
    model,
    system_prompt="Capitalize all the vowles in the given description",
    output_type=str
)

ShortAg = Agent(
    model,
    system_prompt="Cut short the description to be within 3 lines only",
    output_type=str
)

CountAg = Agent(
    model,
    system_prompt="Print the description and then, Count the number of words and display it",
    output_type=str
)



seq_agent = SequentialAgent([Visualize, RefineDescription, ShortAg, CountAg])

# seq_agent.show_mermaid_diagram()

import asyncio

async def main():
    text = "Visualize a car made in Rome in 12BC"
    result = await seq_agent.run(text)
    print("Final output:", result)


# async def main():
#     text = "BMW M2 competetion"
#     result = await seq_agent.run(text)
#     print("Final output (French summary):", result)

if __name__ == "__main__":
    asyncio.run(main())

